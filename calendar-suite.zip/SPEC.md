# SPEC.md — Calendar Suite Requirements

이 문서는 “무엇을 만들어야 하는지”를 정의합니다.
Cursor는 **이 SPEC을 기준으로 우선순위(MVP → V1 → Nice-to-have) 순서로 구현**합니다.

---

## 0) Must-follow Constraints
- Web + Mobile은 **동일한 Firebase 프로젝트** 사용
- Firebase 필수 구성:
  - Authentication (Google 1종 이상)
  - Firestore 또는 Realtime DB 중 1개 (권장: Firestore)
- Web 배포: **JCloud** (Firebase Hosting 사용 금지)
- Mobile: **PWA 인정되지 않음** (네이티브 앱으로 실행/빌드)
- 실시간 동기화: 한 계정에서 다중 접속 시 변경사항이 즉시 반영되어야 함

---

## 1) Core Features (MVP)
### 1.1 Auth (Google)
- [ ] Web: Google 로그인/로그아웃 UI
- [ ] Web: 로그인 상태 유지 (새로고침해도 유지)
- [ ] Mobile: Google 로그인/로그아웃
- 완료 기준:
  - 로그인 시 uid/email 표시
  - 로그아웃 시 보호 페이지 접근 불가

### 1.2 Real-time Sync
- [ ] 이벤트/할일 데이터가 두 기기(또는 브라우저 2개 탭)에서 실시간 동기화
- 구현 기준:
  - Firestore `onSnapshot` 기반 구독
  - `updatedAt = serverTimestamp()` 저장
- 완료 기준:
  - A에서 추가/수정/삭제하면 B에서 1~2초 내 반영

### 1.3 Calendar Basics (Web 우선)
- [ ] 월/주/일 뷰 (최소 월 뷰 + 일 상세)
- [ ] 이벤트 CRUD (생성/수정/삭제)
- [ ] All-day 이벤트 지원
- [ ] 드래그 이동(날짜 변경) 저장
- [ ] 일정 클릭 시 상세(수정/삭제)
- 완료 기준:
  - 기본 캘린더 앱 수준의 CRUD 동작

### 1.4 Tasks (To-do)
- [ ] 할일 CRUD
- [ ] 완료 처리(complete toggle)
- [ ] (최소) 마감일(dueAt) 지원
- 완료 기준:
  - 로그인한 유저 단위로 할일 저장/조회

### 1.5 Theme
- [ ] 자동 라이트/다크 모드 (`prefers-color-scheme`)
- [ ] (선택) 사용자 설정으로 강제 라이트/다크 가능
- 완료 기준:
  - OS 설정 바꾸면 자동 반영(또는 새로고침 시 반영)

---

## 2) Calendar Sources (V1)
### 2.1 Holidays / National days
- [ ] 공휴일/기념일 캘린더 자동 표시
- [ ] ON/OFF 토글
- 구현 방식(권장):
  - Holidays를 별도 calendar source로 취급
  - 필요 시 프록시(서버)로 ICS/API 가져오기(CORS 대비)
- 완료 기준:
  - 특정 국가(예: KR) 공휴일이 월 뷰에 표시되고 토글로 숨김 가능

### 2.2 External calendars (School / Institute) — Optional
- [ ] 기관 캘린더(ICS URL 등) 추가
- [ ] ON/OFF 토글
- [ ] readOnly 표시
- 완료 기준:
  - URL 등록 후 이벤트가 보이고, OFF 시 숨김

---

## 3) Mobile App Requirements (V1)
- [ ] Web과 동일 Firebase 프로젝트 사용
- [ ] 로그인/로그아웃
- [ ] 이벤트 리스트(월 기준) + 추가/삭제
- [ ] 실시간 동기화
- (선택) 월 달력 UI
- 완료 기준:
  - 최소 기능으로도 Web과 데이터가 연동되어 동일하게 보임

---

## 4) Data Model (Proposed)
> 실제 구현 시 조정 가능하나, “기간 조회”/“토글”/“실시간 동기화”가 최우선.

### 4.1 Paths
- `users/{uid}`
- `users/{uid}/settings/{doc}` 또는 `users/{uid}` 안에 settings 필드
- `users/{uid}/calendars/{calendarId}`
- `users/{uid}/events/{eventId}`
- `users/{uid}/tasks/{taskId}`

### 4.2 Event fields (minimum)
- `title: string`
- `startAt: Timestamp`
- `endAt: Timestamp`
- `allDay: boolean`
- `calendarId: string`
- `createdAt: serverTimestamp`
- `updatedAt: serverTimestamp`
- (성능 옵션) `monthKey: "YYYY-MM"`

### 4.3 Calendar source
- `type: "personal" | "holidays" | "ics"`
- `enabled: boolean`
- `readOnly: boolean`
- `source?: { icsUrl?: string, countryCode?: string }`

---

## 5) Pages / Routes (Web)
- `/login`
- `/app`
  - 캘린더 화면 (월/주/일)
  - 사이드패널: calendars 토글 / tasks / 설정

완료 기준:
- 로그인 전: `/login`만 접근
- 로그인 후: `/app` 접근 가능

---

## 6) Security Rules (Minimum)
- [ ] 인증된 사용자만 접근
- [ ] `users/{uid}/**`는 본인 uid만 read/write
- 완료 기준:
  - 다른 uid 문서 접근 시 권한 거부

---

## 7) JCloud Deployment (Web)
- [ ] Vite build → dist 산출
- [ ] Nginx(or Docker)로 정적 배포
- [ ] SPA 라우팅 설정
- 완료 기준:
  - JCloud URL로 접속 시 동작
  - Firebase Hosting 사용하지 않음

---

## 8) Non-functional Requirements
- [ ] 로딩/에러 상태 표시(스피너/토스트)
- [ ] 시간대/로케일 기본값 처리
- [ ] 성능: 월 뷰 로딩 2초 내(일반 네트워크 기준 목표)
- [ ] 코드 품질: 타입에러/린트에러 0

---

## 9) Milestones
### M0 — Repo & Apps ready
- web/mobile 실행 성공

### M1 — Auth + Firestore CRUD + Sync
- 로그인 + 이벤트/할일 CRUD + 실시간 동기화

### M2 — Calendar UI V1
- FullCalendar 등으로 월뷰/드래그 저장

### M3 — Holidays + External calendar toggle
- 공휴일 표시 + (선택) ICS 가져오기

### M4 — Mobile V1
- 로그인 + 리스트/CRUD + sync

### M5 — JCloud Deploy
- Web 배포 완료 + 문서화