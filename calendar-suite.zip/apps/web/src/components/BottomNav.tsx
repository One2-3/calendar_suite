// apps/web/src/components/BottomNav.tsx
import { Menu, PencilLine, Search } from "lucide-react";

export default function BottomNav(props: {
  onMenu: () => void;
  onCompose: () => void;
  onSearch: () => void;
  active?: "home" | "search";
}) {
  const { onMenu, onCompose, onSearch, active } = props;

  return (
    <nav className="bottom-nav">
      <div className="bottom-nav-inner">
        <button className="nav-btn" onClick={onMenu} aria-label="menu">
          <Menu size={18} />
          <span>메뉴</span>
        </button>
        <button className="nav-btn primary" onClick={onCompose} aria-label="compose">
          <PencilLine size={18} />
          <span>작성</span>
        </button>
        <button className="nav-btn" onClick={onSearch} aria-label="search">
          <Search size={18} />
          <span>{active === "search" ? "검색중" : "검색"}</span>
        </button>
      </div>
    </nav>
  );
}
