// 임시 테스트 파일 - 문제 진단용

export const TestApp = () => {
  return (
    <div style={{ padding: '2rem', backgroundColor: 'white', color: 'black' }}>
      <h1>테스트 페이지</h1>
      <p>이 페이지가 보이면 React는 정상 작동 중입니다.</p>
    </div>
  );
};







