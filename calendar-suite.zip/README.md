# Calendar Suite (Web + Mobile)

캘린더 기반 일정/할일 관리 앱 (Web + Mobile).
- Web: React + TypeScript (Vite)
- Mobile: React Native (Expo) + TypeScript
- Backend: Firebase Authentication + Firestore (Web/Mobile 동일 Firebase 프로젝트 사용)
- 배포: Web은 **JCloud에 배포** (Firebase Hosting 사용 금지)
- Mobile: **PWA 금지** (네이티브 앱으로 실행/빌드)

## Goals
- 구글 소셜 로그인
- 한 계정 다중 접속 시 **실시간 동기화**
- 공휴일/기념일 캘린더 자동 연동
- 학교 등 기관 캘린더(ICS 등) 가져오기 + ON/OFF
- 사용자가 쓰는 캘린더와 동일한 UI/UX (최대한 유사)
- 자동 라이트/다크 모드 지원
- 일반적인 캘린더 앱 기본 기능 전부 포함 (CRUD/드래그/월·주·일 등)

---

## Monorepo Structure

calender-suite/
apps/
  web/ # React WebApp
  mobile/ # React Native Expo
server/ # FastAPI Backend
packages/ # (optional) shared libs (types, utils, firebase helpers)
.vscode/
pnpm-workspace.yaml
package.json

yaml
코드 복사

> `packages/`는 지금 없어도 됩니다. 필요 시 생성합니다.

---

## Prerequisites
- Node.js LTS (권장: 20+)
- pnpm
- Git
- (Mobile) Android Studio / Xcode(macOS)

설치 확인:
```bash
node -v
pnpm -v
git --version
Install & Run
Install
루트에서:

bash
코드 복사
pnpm install
Run Web
bash
코드 복사
pnpm --filter web dev
Run Mobile (Expo)
bash
코드 복사
pnpm --filter mobile start
(편의 스크립트가 있다면)

bash
코드 복사
pnpm dev:web
pnpm dev:mobile
Firebase Setup (Required)
1) Firebase 프로젝트 생성
Firebase Console에서:

새 프로젝트 생성

Authentication 활성화 → Sign-in method에서 Google 활성화

Firestore Database 생성

2) Firebase에 Web App 등록
Firebase 프로젝트 설정 → 앱 추가(Web) → config 값 확보

Web 환경변수 파일 생성:

apps/web/.env

예시:

env
코드 복사
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_STORAGE_BUCKET=...
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
3) Firebase에 Android/iOS App 등록 (Mobile)
Firebase 프로젝트 설정 → 앱 추가(Android, iOS)

Android: package name

iOS: bundle id

Expo/React Native 연동 방식은 SPEC.md의 Mobile 섹션 기준으로 진행합니다.

Deployment (Web on JCloud, NOT Firebase Hosting)
Web 앱은 Vite 빌드 후 정적 파일(dist/)을 JCloud 서버(Nginx 또는 Docker)로 서빙합니다.

기본 흐름:

로컬/CI에서 pnpm --filter web build

apps/web/dist를 서버로 업로드

Nginx로 SPA 라우팅 설정 (try_files $uri /index.html;)

Firebase Hosting은 사용하지 않습니다.

Coding Conventions (Project-wide)
TypeScript 사용

경로 기반 import 선호

커밋 단위는 작게 (기능 1개 = PR/커밋 1~2개 수준)

폴더/파일명 규칙:

React 컴포넌트: PascalCase.tsx

hooks: useSomething.ts

util: something.ts

Firestore 시간 필드는 Timestamp 또는 serverTimestamp() 기반

Cursor Instructions (Important)
Cursor가 작업할 때 아래 규칙을 지키도록 합니다.

Output format
변경/생성 파일을 경로 단위로 먼저 나열

그 다음 각 파일의 코드 제공

마지막에 실행/테스트 커맨드 제공

Scope control
한 번에 너무 많은 파일 수정 금지

작업은 작게 쪼개서 (Auth → CRUD → Calendar UI → Holidays/ICS → Mobile)

Quality bar
린트/타입에러 0

하드코딩 최소화 (설정/상수 분리)

에러 핸들링/로딩 상태 포함

Next Steps (Suggested Order)
Web Firebase 초기화 + Google 로그인/로그아웃 + Protected Route

Firestore events/tasks CRUD + 실시간 동기화(onSnapshot)

Calendar UI(월/주/일) 연결 + 드래그 이동/리사이즈 저장

공휴일 캘린더 소스 + ON/OFF

기관(ICS) 캘린더 가져오기 + ON/OFF (+ 필요 시 프록시)

Mobile 최소 기능(로그인 + 이벤트 리스트 + CRUD + 동기화)

JCloud 배포 자동화

